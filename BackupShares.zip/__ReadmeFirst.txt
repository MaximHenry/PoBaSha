Important Information First:

I haven't tested these scripts
with shares/subshares containing
spaces in it's names.

The Description_Files
begin with a _ for easier
directory listing.

June 2014 Bavaria

Maximilian Weigmann



